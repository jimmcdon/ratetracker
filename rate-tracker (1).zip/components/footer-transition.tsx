export function FooterTransition() {
  return <div className="h-24 bg-gradient-to-b from-white to-gray-900"></div>
}

